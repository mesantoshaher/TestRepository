import streamlit as st
import json
from models import Request, Preferences
from graph import app_graph

st.set_page_config(layout="wide", page_title="Store Product Assistant")
st.title("Store Product Assistant")

col1, col2 = st.columns([1, 2])

with col1:
    st.subheader("Customer question")
    question = st.text_input("Question", "Which of these is better for long flights?")
    
    st.subheader("Product IDs")
    product_ids = st.multiselect("Products", ["HP-100", "HP-200", "HP-300", "HP-999"], default=["HP-100", "HP-200"])
    
    budget = st.number_input("Budget (max, Rs)", value=10000)
    must_have = st.text_input("Must have", "noise cancellation")
    use_case = st.text_input("Use case", "travel")
    
    if st.button("Ask assistant", type="primary"):
        req_data = Request(
            question=question,
            product_ids=product_ids,
            preferences=Preferences(
                budget_max_inr=budget,
                must_have=[must_have] if must_have else [],
                use_case=use_case
            )
        )
        
        # Run Graph
        with st.spinner("Processing..."):
            result = app_graph.invoke({"request": req_data})
            st.session_state['response'] = result['response']

with col2:
    if 'response' in st.session_state:
        res = st.session_state['response']
        
        if res.recommendation:
            st.success(f"**{res.recommendation.product_id}**\n\n{res.recommendation.reasoning}")
        elif res.escalate:
            st.error(f"**Supervisor Review Required**\n\n{res.escalation_reason}")
        elif res.missing_preferences:
            st.warning("Cannot recommend without preferences.")
            
        if res.comparison:
            st.write("### Comparison")
            table_data = {"Attribute": res.comparison.attributes}
            for row in res.comparison.rows:
                table_data[row.product_id] = row.values
            st.table(table_data)
            
            # Citations
            citations = set()
            for row in res.comparison.rows:
                for c in row.citations: citations.add(c)
            st.caption(f"Sources: {', '.join(citations)}")
            
        if res.missing_preferences:
            st.info(f"**Missing:** {', '.join(res.missing_preferences)}")
            
        if res.unsupported:
            st.warning(f"**Not supported:** {', '.join(res.unsupported)}")
            
        if res.data_conflicts:
            for c in res.data_conflicts:
                st.caption(f"*Data Conflict Handled:* {c.product_id} - {c.attribute} ({c.resolution})")
                
        if not res.escalate:
            st.success("🟢 Supervisor review: not needed")
        else:
            st.warning("🟡 Supervisor review: pending")

        with st.expander("Raw JSON Response"):
            st.json(res.model_dump())