import json
from datetime import datetime

def load_data():
    with open('data/catalog.json', 'r') as f:
        catalog = json.load(f)
    with open('data/policies.json', 'r') as f:
        policies = json.load(f)
    return catalog + policies

def retrieve_and_resolve(product_ids, session_date="2026-10-12"):
    docs = load_data()
    session_dt = datetime.strptime(session_date, "%Y-%m-%d")
    
    valid_docs = []
    conflicts = []
    
    # Group by product to find conflicts
    product_docs = {pid: [] for pid in product_ids}
    for doc in docs:
        pid = doc.get("product_id", doc.get("id"))
        if pid in product_docs and doc.get("approved"):
            product_docs[pid].append(doc)
            
    for pid, doc_list in product_docs.items():
        if not doc_list: continue
        
        # Sort by effective_date descending
        doc_list.sort(key=lambda x: x.get("effective_date", "1970-01-01"), reverse=True)
        
        latest_doc = doc_list[0]
        valid_docs.append(latest_doc)
        
        # Detect conflicts
        if len(doc_list) > 1:
            attr_conflict = False
            for key in latest_doc["content"]:
                if key in doc_list[1]["content"] and latest_doc["content"][key] != doc_list[1]["content"][key]:
                    attr_conflict = True
                    conflicts.append({
                        "product_id": pid,
                        "attribute": key,
                        "sources": [doc_list[1]["id"], latest_doc["id"]],
                        "resolution": "Used latest effective version"
                    })
                    break
                    
    return valid_docs, conflicts