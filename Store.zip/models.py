from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any

class Preferences(BaseModel):
    budget_max_inr: Optional[int] = None
    must_have: List[str] = []
    use_case: Optional[str] = None

class Request(BaseModel):
    question: str
    product_ids: List[str]
    preferences: Preferences
    session_date: str = "2026-10-12" # Fixed for deterministic testing

class Fact(BaseModel):
    product_id: str
    attribute: str
    value: str
    citation: str

class ComparisonRow(BaseModel):
    product_id: str
    values: List[str]
    citations: List[str]

class Comparison(BaseModel):
    attributes: List[str]
    rows: List[ComparisonRow]

class Recommendation(BaseModel):
    product_id: str
    reasoning: str
    based_on_preferences: List[str]

class DataConflict(BaseModel):
    product_id: str
    attribute: str
    sources: List[str]
    resolution: str

class Response(BaseModel):
    intent: str
    facts: List[Fact]
    comparison: Optional[Comparison] = None
    recommendation: Optional[Recommendation] = None
    missing_preferences: List[str] = []
    unsupported: List[str] = []
    data_conflicts: List[DataConflict] = []
    escalate: bool = False
    escalation_reason: Optional[str] = None
