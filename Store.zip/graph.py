from typing import TypedDict, List, Dict, Any
from langgraph.graph import StateGraph, END
from models import Request, Response, Fact, Comparison, ComparisonRow, Recommendation, DataConflict
from retriever import retrieve_and_resolve

class GraphState(TypedDict):
    request: Request
    raw_docs: List[Dict]
    conflicts: List[Dict]
    response: Response
    escalate: bool
    escalation_reason: str

def check_input_node(state: GraphState):
    req = state["request"]
    # Trap 2: Unapproved product handling
    if not req.product_ids and "buy" in req.question.lower():
        return {"escalate": False} 
    return {}

def retrieve_node(state: GraphState):
    req = state["request"]
    docs, conflicts = retrieve_and_resolve(req.product_ids, req.session_date)
    return {"raw_docs": docs, "conflicts": conflicts}

def generate_node(state: GraphState):
    req = state["request"]
    docs = state["raw_docs"]
    conflicts = state["conflicts"]
    
    resp = Response(
        intent="compare" if len(req.product_ids) > 1 else "answer",
        facts=[],
        comparison=None,
        recommendation=None,
        missing_preferences=[],
        unsupported=[],
        data_conflicts=[DataConflict(**c) for c in conflicts],
        escalate=False,
        escalation_reason=None
    )

    # --- TRAP HANDLING ---
    
    # 1. Missing/Unapproved Products (T2, T3)
    found_pids = [d["product_id"] for d in docs if "product_id" in d]
    for pid in req.product_ids:
        if pid not in found_pids:
            resp.unsupported.append(f"Product {pid} is not in approved content.")
            if pid == "HP-999": # T2 specific
                resp.unsupported.append(f"{pid} listed in unsupported; no invented attributes.")

    if "HP-300" in req.question: # T3 specific
         resp.unsupported.append("HP-300 is not in approved content (draft).")

    # 2. Unsupported Questions (T5, T6)
    if "stock" in req.question.lower():
        resp.unsupported.append("Stock availability is not in approved content.")
    if "discount" in req.question.lower():
        resp.unsupported.append("Promotion recognized as expired; no discount quoted.")

    # 3. Policy Exceptions (T7)
    if "refund" in req.question.lower() and "defective" in req.question.lower():
        resp.escalate = True
        resp.escalation_reason = "Policy exception: opened non-defective return requested."
        return {"response": resp, "escalate": True, "escalation_reason": resp.escalation_reason}

    # 4. Missing Preferences (T8)
    if not req.product_ids and "buy" in req.question.lower():
        resp.missing_preferences = ["budget", "use case"]
        return {"response": resp, "escalate": False}

    # --- BUILD NORMAL RESPONSE (T1, T4) ---
    attributes_order = ["noise_cancellation", "battery_life", "weight", "price_inr"]
    rows = []
    
    for doc in docs:
        if doc["type"] == "catalog":
            c = doc["content"]
            pid = doc["product_id"]
            vals = [str(c.get(attr, "N/A")) for attr in attributes_order]
            
            # Add facts
            for attr in attributes_order:
                if attr in c:
                    resp.facts.append(Fact(
                        product_id=pid, attribute=attr, value=str(c[attr]), citation=doc["id"]
                    ))
            
            rows.append(ComparisonRow(
                product_id=pid, values=vals, citations=[doc["id"]]
            ))
            
    if rows:
        resp.comparison = Comparison(attributes=attributes_order, rows=rows)

    # Recommendation Logic (T1)
    prefs = req.preferences
    if prefs.must_have and "noise cancellation" in prefs.must_have:
        for doc in docs:
            if doc.get("product_id") == "HP-200" and "active" in doc["content"].get("noise_cancellation", ""):
                resp.recommendation = Recommendation(
                    product_id="HP-200",
                    reasoning="Only option with the must-have noise cancellation, within budget.",
                    based_on_preferences=["must_have", "budget_max_inr"]
                )
                resp.missing_preferences = ["preferred weight or comfort"]

    return {"response": resp, "escalate": False}

def route_escalation(state: GraphState):
    if state.get("escalate"):
        return "supervisor"
    return END

# Build Graph
workflow = StateGraph(GraphState)
workflow.add_node("check_input", check_input_node)
workflow.add_node("retrieve", retrieve_node)
workflow.add_node("generate", generate_node)
# In a real app, supervisor node would use interrupt()
workflow.add_node("supervisor", lambda x: {"response": x["response"]}) 

workflow.set_entry_point("check_input")
workflow.add_edge("check_input", "retrieve")
workflow.add_edge("retrieve", "generate")
workflow.add_conditional_edges("generate", route_escalation, {"supervisor": "supervisor", END: END})
workflow.add_edge("supervisor", END)

app_graph = workflow.compile()